package treesyntax;

public class TreeSyntax {
        public static void main(String[] args){
            Interfaz lo = new Interfaz();
            lo.setVisible(true);
            
        }
}