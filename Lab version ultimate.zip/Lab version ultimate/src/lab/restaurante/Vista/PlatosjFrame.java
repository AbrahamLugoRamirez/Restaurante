/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.restaurante.Vista;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import lab.restaurante.controlador.Limpiar_tabla;
import lab.restaurante.controlador.*;
import lab.restaurante.modelo.*;

/**
 *
 * @author labraham
 */
public class PlatosjFrame extends javax.swing.JFrame {

    /**
     * Creates new form PlatosjFrame
     */
    static Ordenes m = new Ordenes();
    static menujFrame n = new menujFrame();
    static Listado_p o = new Listado_p();
    Carga_platos cargap = new Carga_platos();
    Carga_bebidas cargab = new Carga_bebidas();
    Carga_postres cargapo = new Carga_postres();
    

    void añadir() {

        DefaultTableModel model = (DefaultTableModel) listaplatosjTable.getModel();
        DefaultTableModel modelcompra = (DefaultTableModel) listaplatosjTable1.getModel();
        int fila = listaplatosjTable.getSelectedRow();

        if (fila != -1) {

            long codigo = (Long)model.getValueAt(fila, 0);
            Object nombre = model.getValueAt(fila, 1);
            Object precio = model.getValueAt(fila, 2);
            
            if(!cargapo.hay(codigo, "Postres") || !cargapo.hay(codigo, "Platos") || !cargapo.hay(codigo, "Bebidas")){
                Ordenes.noHabia.setColumnIdentifiers(new Object[]{"Codigo","Nombre","Precio"});
                Ordenes.noHabia.addRow(new Object[]{codigo,nombre,precio});
                JOptionPane.showMessageDialog(null, "No hay "+nombre+" En existencia", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            modelcompra.addRow(new Object[]{codigo, nombre, precio});
            
                try {
                    
                    gastarRecursos(codigo, "Platos");
                    gastarRecursos(codigo, "Postres");
                    gastarRecursos(codigo, "Bebidas");
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(PlatosjFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            

        } else {
            JOptionPane.showMessageDialog(null, "No hay Item seleccionado", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }

    }
    
    
   public boolean compra(){
       boolean compro=false;
       DefaultTableModel modelcompra = (DefaultTableModel) listaplatosjTable1.getModel();
       
       if(modelcompra.getRowCount()<=0){
           return compro;
       }
   
       return compro=true;
   }
    

    void quitar() {
        int fila = listaplatosjTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel) listaplatosjTable1.getModel();

        if (fila > -1) {
            long codigo = (Long)model.getValueAt(fila, 0);
            model.removeRow(fila);
            
            try {
                    
                    reponerRecursos(codigo, "Platos");
                    reponerRecursos(codigo, "Postres");
                    reponerRecursos(codigo, "Bebidas");
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(PlatosjFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            
        } else {
            JOptionPane.showMessageDialog(null, "No quedan Items", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }

    }

    void Total() {
        int filas = listaplatosjTable1.getRowCount();
        DefaultTableModel model = (DefaultTableModel) listaplatosjTable1.getModel();
        float suma = 0;
        for (int i = 0; i < filas; i++) {

            Object precio = model.getValueAt(i, 2);

            float preciol = (float) precio;
            suma = suma + preciol;
        }
        resu.setText(String.valueOf(suma));
    }

    public PlatosjFrame() {
        initComponents();
        this.setLocationRelativeTo(null);
        listaplatosjTable.getColumnModel().getColumn(0).setPreferredWidth(5);
        listaplatosjTable1.getColumnModel().getColumn(0).setPreferredWidth(5);

    }

    public void gastarRecursos(long cod, String path) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("assets/" + path + ".txt"));

        while (sc.hasNextLine()) {
            String s = sc.nextLine();
            String[] datos = s.split(",");
            long codigo = Long.parseLong(datos[0]);
            if (codigo == cod) {
                Scanner scing = new Scanner(new File("assets/Ingredientes.txt"));
                ArrayList<String> ingredientes = new ArrayList<>();
                ArrayList<Long> cantidad = new ArrayList<>();
                int cont = 0;
                while (scing.hasNextLine()) {
                    String st = scing.nextLine();
                    String ingre[]  = st.split(",");
                    ingredientes.add(ingre[0]);
                    cantidad.add(Long.parseLong(ingre[1]));
                    for (int i = 3; i < datos.length; i++) {
                        if(ingre[0].equals(datos[i])){
                            cantidad.set(cont, cantidad.get(cont)-1);
                            
                        }
                    }
                    cont++;
                }
                scing.close();
                
                PrintWriter pw = new PrintWriter(new File("assets/Ingredientes.txt"));
                for(int i=0; i<ingredientes.size(); i++){
                    pw.write(ingredientes.get(i)+","+cantidad.get(i)+"\n");
                }
                pw.close();
                break;
            }
        }

        sc.close();
    }
    
        public void reponerRecursos(long cod, String path) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("assets/" + path + ".txt"));

        while (sc.hasNextLine()) {
            String s = sc.nextLine();
            String[] datos = s.split(",");
            long codigo = Long.parseLong(datos[0]);
            if (codigo == cod) {
                Scanner scing = new Scanner(new File("assets/Ingredientes.txt"));
                ArrayList<String> ingredientes = new ArrayList<>();
                ArrayList<Long> cantidad = new ArrayList<>();
                int cont = 0;
                while (scing.hasNextLine()) {
                    String st = scing.nextLine();
                    String ingre[]  = st.split(",");
                    ingredientes.add(ingre[0]);
                    cantidad.add(Long.parseLong(ingre[1]));
                    for (int i = 3; i < datos.length; i++) {
                        if(ingre[0].equals(datos[i])){
                            cantidad.set(cont, cantidad.get(cont)+1);
                            
                        }
                    }
                    cont++;
                }
                scing.close();
                
                PrintWriter pw = new PrintWriter(new File("assets/Ingredientes.txt"));
                for(int i=0; i<ingredientes.size(); i++){
                    pw.write(ingredientes.get(i)+","+cantidad.get(i)+"\n");
                }
                pw.close();
                break;
            }
        }

        sc.close();
    }
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        listaplatosjTable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaplatosjTable1 = new javax.swing.JTable();
        añdirpljButton = new javax.swing.JButton();
        canpljButton = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        listopljButton = new javax.swing.JButton();
        resu = new javax.swing.JTextField();
        PlatosjButton = new javax.swing.JButton();
        BebidasjButton = new javax.swing.JButton();
        PostresjButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        listaplatosjTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        listaplatosjTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cod", "Nombre", "Precio"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(listaplatosjTable);
        if (listaplatosjTable.getColumnModel().getColumnCount() > 0) {
            listaplatosjTable.getColumnModel().getColumn(1).setResizable(false);
            listaplatosjTable.getColumnModel().getColumn(2).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 585, 233));

        listaplatosjTable1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        listaplatosjTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cod", "Nombre", "Precio"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(listaplatosjTable1);
        if (listaplatosjTable1.getColumnModel().getColumnCount() > 0) {
            listaplatosjTable1.getColumnModel().getColumn(0).setResizable(false);
            listaplatosjTable1.getColumnModel().getColumn(1).setResizable(false);
            listaplatosjTable1.getColumnModel().getColumn(2).setResizable(false);
        }

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 328, 588, 176));

        añdirpljButton.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        añdirpljButton.setText("Añadir");
        añdirpljButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                añdirpljButtonActionPerformed(evt);
            }
        });
        getContentPane().add(añdirpljButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(608, 111, -1, 40));

        canpljButton.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        canpljButton.setText("Quitar");
        canpljButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                canpljButtonActionPerformed(evt);
            }
        });
        getContentPane().add(canpljButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 330, 80, -1));

        jLabel4.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("TOTAL: ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 520, 90, 30));

        listopljButton.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        listopljButton.setText("Listo");
        listopljButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listopljButtonActionPerformed(evt);
            }
        });
        getContentPane().add(listopljButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 520, 81, -1));

        resu.setEditable(false);
        resu.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        getContentPane().add(resu, new org.netbeans.lib.awtextra.AbsoluteConstraints(373, 523, 151, -1));

        PlatosjButton.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        PlatosjButton.setText("Platos");
        PlatosjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlatosjButtonActionPerformed(evt);
            }
        });
        getContentPane().add(PlatosjButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 22, 115, -1));

        BebidasjButton.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        BebidasjButton.setText("Bebidas");
        BebidasjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BebidasjButtonActionPerformed(evt);
            }
        });
        getContentPane().add(BebidasjButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(234, 22, -1, -1));

        PostresjButton.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        PostresjButton.setText("Postres");
        PostresjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PostresjButtonActionPerformed(evt);
            }
        });
        getContentPane().add(PostresjButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(396, 22, 120, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoAzul.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void listopljButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listopljButtonActionPerformed
        // TODO add your handling code here:
        menujFrame jFrame = new menujFrame();
        jFrame.setVisible(true);
        jFrame.setVisible(true);
        this.setVisible(false);
        
        if(compra()==true){
            
            m.agregarOrden().detalles = (DefaultTableModel) listaplatosjTable1.getModel();

            
            
           
        
            
        }else{
            JOptionPane.showMessageDialog(null, "No añadio nada a la compra, no se generara su Orden", "Advertencia", JOptionPane.WARNING_MESSAGE);
        
        }

        

    }//GEN-LAST:event_listopljButtonActionPerformed

    private void añdirpljButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_añdirpljButtonActionPerformed

        añadir();

        Total();
    }//GEN-LAST:event_añdirpljButtonActionPerformed

    private void canpljButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_canpljButtonActionPerformed

        quitar();
        Total();
    }//GEN-LAST:event_canpljButtonActionPerformed

    private void PlatosjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlatosjButtonActionPerformed

        Limpiar_tabla.limpiar(listaplatosjTable);
        cargap.cargar_archivos_Platos(listaplatosjTable);
    }//GEN-LAST:event_PlatosjButtonActionPerformed

    private void BebidasjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BebidasjButtonActionPerformed

        Limpiar_tabla.limpiar(listaplatosjTable);
        cargab.cargar_archivos_Bebidas(listaplatosjTable);
    }//GEN-LAST:event_BebidasjButtonActionPerformed

    private void PostresjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PostresjButtonActionPerformed

        Limpiar_tabla.limpiar(listaplatosjTable);
        cargapo.cargar_archivos_Postre(listaplatosjTable);

    }//GEN-LAST:event_PostresjButtonActionPerformed

    /**
     * @param args the command line arguments
     */
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BebidasjButton;
    private javax.swing.JButton PlatosjButton;
    private javax.swing.JButton PostresjButton;
    private javax.swing.JButton añdirpljButton;
    private javax.swing.JButton canpljButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable listaplatosjTable;
    private javax.swing.JTable listaplatosjTable1;
    private javax.swing.JButton listopljButton;
    private javax.swing.JTextField resu;
    // End of variables declaration//GEN-END:variables
}
