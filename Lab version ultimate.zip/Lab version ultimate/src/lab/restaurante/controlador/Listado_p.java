/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.restaurante.controlador;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jhanki Negrete
 */
public class Listado_p {
    
    
    public static class Listado{
        long cod;
        String nombre;
        Listado link;
        
       /* public Listado(int cod, String nombre){
            this.cod = cod;
            this.nombre=nombre;
            link = null;
        }*/
    }
    
    public static Listado ptr;
    
    public static Listado obtener_listado(DefaultTableModel model, int i){
        
        
        
        
            
            Listado p=new Listado();
            
            
            
        //    p.cod = (long) model.getValueAt(i, 0);
            p.nombre= (String)model.getValueAt(i, 0);
            if(ptr == null){
                ptr = p;
            }else{
                Listado q = ptr;
                while(q.link != null){
                    q = q.link;
                }
                q.link = p;
            }
            
            
           //  return ptr;
            
        
        
        
        return ptr;
    }
    
    
    
    public static void proba(){
            Listado p = ptr;
            while(p != null){
                
                JOptionPane.showMessageDialog(null, p.nombre, "Muestra", JOptionPane.INFORMATION_MESSAGE);

                p = p.link;
            }
    
    }
    
    public static String mas_vendido(){
        Listado p = ptr;
        String nombre="";
        int mayor = 0;
        int cont = 0;
        
        while(p.link != null){
            Listado q = ptr;
            while(q != null){
                
                if(p.nombre.equals(q.nombre)){
                    cont = cont+1;
                }
                q = q.link;
            }
            if(cont>mayor){
                mayor = cont;
                
                nombre = p.nombre;
                
            }
            cont=0;
            p=p.link;
            
        
        }
        
        return nombre;    
    }
    
}


