/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.restaurante.controlador;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jhanki Negrete
 */
public class Ordenes {
    
    public static int Contventas=0;
    
    {
        if(ptrm==null){
            Mesero q;
            ptrm = new Mesero(1, "Juan Restrepo");
            Mesero p = new Mesero(2, "Agustin");
            ptrm.link = p;
            q = new Mesero(3, "Guille");
            p.link = q;
            q = new Mesero(4, "Mañe");
            p.link.link = q;
        }
        
    }
    
    public static DefaultTableModel noHabia = new DefaultTableModel();
    
    public static class Mesero{
        int cont;
        int cod;
        String nombre;
        Mesero link;
        
        public Mesero(int cod, String nombre){
            this.cod = cod;
            this.cont = 0;
            this.nombre=nombre;
            link = null;
        }
    }
    
    public static void meseroVendio(int numMesa){
        Mesero p = ptrm;
        while(p!=null){
            if(p.cod == (numMesa-1)/5+1){
                p.cont++;
                break;
            }
            p=p.link;
        }
    }
    
    public static void mostrarMeseros(DefaultTableModel m){
        Mesero p = ptrm;
        while(p!=null){
            m.addRow(new Object[]{p.cod, p.nombre, p.cont});
            p=p.link;
        }
    }
    
    public static class Venta{
        float total;
        int numFact;
        int mesa;
        public DefaultTableModel detalles;
        Venta link;
        
        public Venta(float total, int numFact, int mesa, DefaultTableModel detalles){
            this.detalles=detalles;
            this.numFact=numFact;
            this.total=total;
            this.mesa = mesa;
            this.link = null;
        }
    }
    public static class Nodo {

        static int cont = 0;
        int numorden;
        int nummesa;
        public String estado;
        public DefaultTableModel detalles;

        Nodo link;

    }

    public static int mesa;
    public Nodo ptr;
    static public Venta ptrf;
    public static Mesero ptrm;
    
    static public Mesero agregarMesero(int cod, String nombre) {
        Mesero p = new Mesero(cod, nombre);
        if (ptrm == null) {
            ptrm = p;
        } else {
            Mesero q = ptrm;
            while (q.link != null) {
                q = q.link;
            }
            q.link = p;
        }
        return p;
    }
    
    static public Venta agregarVenta(float total, int numFact, int mesa, DefaultTableModel detalles) {
        Venta p = new Venta(total, numFact, mesa, detalles);
        if (ptrf == null) {
            ptrf = p;
        } else {
            Venta q = ptrf;
            while (q.link != null) {
                q = q.link;
            }
            q.link = p;
        }
        Contventas++;
        return p;
    }
    
    public static Venta buscarFactura(int num){
        Venta p = ptrf;
        while(p!=null && p.numFact!=num){
            p=p.link;
        }
        return p;
    }
    public static void resumenVentas(DefaultTableModel model){
        Venta p = ptrf;
        
        while(p!=null){
            model.addRow(new Object[]{p.numFact, p.mesa, p.total});
            p = p.link;
            
        }
    }

    public Nodo agregarOrden() {
        Nodo p = new Nodo();
        p.numorden = ++Nodo.cont;
        p.nummesa = mesa;
        p.estado = "Incompleto";
        if (ptr == null) {
            ptr = p;
        } else {
            Nodo q = ptr;
            while (q.link != null) {
                q = q.link;
            }
            q.link = p;
        }
        return p;
    }
    
    public float facturarMesa(int mesa, JTable t, JLabel l){
         Nodo q = ptr, ant = null;
         
         DefaultTableModel model = new DefaultTableModel(new Object [][] {}, new String [] {"Consumido", "Precio"}){
             boolean[] canEdit = new boolean [] {
             false, false
            };
             public boolean isCellEditable(int rowIndex, int columnIndex) {
             return canEdit [columnIndex];
            }
         };
        float sum = 0,iva = 0,propina = 0, sub = 0;
        
        while(q!=null){
            if(q.nummesa==mesa && "Listo".equals(q.estado)){
                for (int i = 0; i < q.detalles.getRowCount(); i++) {
                    model.addRow(new Object[]{q.detalles.getValueAt(i, 1), q.detalles.getValueAt(i, 2)});
                    sum = sum + (Float)q.detalles.getValueAt(i, 2);
                    Listado_p.obtener_listado(model, i);
                }
                if(q==ptr){
                    ptr = q.link;
                }else{
                    ant.link = q.link;
                }
                
            }
            ant=q;
            q=q.link;
        }
        sub = sum;
        iva=(float) (sum*0.19);
        propina=(float)(sum*0.1);
        t.setModel(model);
        model.addRow(new Object[]{"",""});
        model.addRow(new Object[]{" SUB-TOTAL",sub});
        model.addRow(new Object[]{"",""});
        model.addRow(new Object[]{" IVA",iva});
        model.addRow(new Object[]{" PROPINA",propina});
        sum=sum + iva + propina;
        l.setText("$ "+sum);
        
        return sum;
    }

    public void mostrarLista(JTable tabla, Nodo ptr) {
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();
        model.setRowCount(0);

        Nodo p = ptr;
        while (p != null) {
            System.out.println(p.estado);
            if(p.estado.equals("Incompleto"))
            model.addRow(new Object[]{p.numorden, p.nummesa, p.estado});
            p = p.link;
        }

    }

    public void eliminarOrden(int numorden) {
        Nodo q = ptr;
        Nodo ant = null;

        while (q != null && q.numorden != numorden) {
            ant = q;
            q = q.link;
        }
        if (q != null) {
            if (q == ptr) {
                ptr = ptr.link;
            } else {
                ant.link = q.link;
            }
        }
    }
    
    public Nodo buscarOrden(int n){
        Nodo q = ptr;
        
        while(q!=null && q.numorden!=n){
            q = q.link;
        }
        
        return q;
    }

}
