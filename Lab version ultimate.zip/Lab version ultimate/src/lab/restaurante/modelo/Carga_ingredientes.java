/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.restaurante.modelo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jhanki Negrete
 */
public class Carga_ingredientes {
    
    File archivo;
    
    
    
    
       void mostrarError(String titulo, String mensaje){
        JOptionPane.showMessageDialog(null,
                mensaje,
                titulo,
                JOptionPane.ERROR_MESSAGE);
    }
         
    
    void limpiarTabla(JTable table){
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
    }
    
   public void cargar_archivos_Ingredientes(JTable tabla){
         archivo = new File("assets/Ingredientes.txt");            
         DefaultTableModel model = (DefaultTableModel) tabla.getModel();
            
            try(Scanner lector = new Scanner(archivo)){
                
                
              
                while(lector.hasNextLine()){
                    
                    String linea = lector.nextLine();            
                    String[] datos = linea.split(",");
                    
                    System.out.println(linea);
                    String nombre = datos[0];
                    long und = Long.parseLong(datos[1]);
                    
                    
                    
                    
                    
                    model.addRow(new Object[]{nombre,und});
                    
                }
            } catch (FileNotFoundException ex) {
                mostrarError("Archivo no existe", "No se pudo encontrar el archivo");
            } catch (NullPointerException ex) {
                mostrarError("Formato equivocado", "El archivo no tiene el formato correcto");
                limpiarTabla(tabla);
            } catch (NumberFormatException ex) {
                mostrarError("Formato equivocado", "Los tipos de datos no coinciden");
                limpiarTabla(tabla);
            } catch (Exception ex){
                mostrarError("Error", "Algo inesperado ocurrió");
               limpiarTabla(tabla);
                ex.printStackTrace();
            }
        
        
    
    }
    
   
   public void actualizar(JTable tabla,long cant, int fila) throws FileNotFoundException{
       
       
       
       // Crear un nuevo escritor
        try(BufferedWriter bw = new BufferedWriter(
            new FileWriter("assets/Ingredientes.txt"))){
            // Hallamos el numero de filas
            int filas = tabla.getRowCount();
            
            // Tomamos el modelo
            DefaultTableModel model = (DefaultTableModel) tabla.getModel();
            
            for(int i = 0; i < filas; ++i) {
                Object nombre = model.getValueAt(i, 0);
                Object cantidad = model.getValueAt(i, 1);
                if(i==fila){
                    Long temp = (Long)cantidad;
                    temp=temp+cant;
                    
                    cantidad=(Object)temp;
                }
                
                bw.write(nombre + "," + cantidad);
                bw.newLine();
                
            }
        } catch (IOException ex) {
            mostrarError("Error con archivo", "No se puede escribir en el archivo.");
        } catch (NullPointerException ex){
            mostrarError("Datos faltantes", "Los datos en la tabla no están completos");
        } catch (NumberFormatException ex) {
            mostrarError("Formato equivocado", "Los números en la tabla no tienen el formato correcto");
        } catch(Exception ex) {
            mostrarError("Error", "Algo inesperado ocurrió");
            ex.printStackTrace();
        }
               
   
   }
    
}
