/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.restaurante.modelo;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import lab.restaurante.controlador.Limpiar_tabla;

/**
 *
 * @author Jhanki Negrete
 */
public class Carga_postres {

    File archivo;
    
    public boolean verSiHay(String[] datos){
        archivo = new File("assets/Ingredientes.txt");

        try (Scanner lector = new Scanner(archivo)) {

            while (lector.hasNextLine()) {
                
                String linea = lector.nextLine();
                System.out.println(linea);
                String[] d = linea.split(",");

                for (int i = 3; i < datos.length; i++) {
                    long temp = Long.parseLong( d[1]);
                    if(d[0].equals(datos[i]) && temp<=0){
                        lector.close();
                        return false;
                    }
                }


            }
        } catch (FileNotFoundException ex) {
            mostrarError("Archivo no existe", "No se pudo encontrar el archivo");
        } catch (NullPointerException ex) {
            mostrarError("Formato equivocado", "El archivo no tiene el formato correcto");
        } catch (NumberFormatException ex) {
            mostrarError("Formato equivocado", "Los tipos de datos no coinciden");
        } 
        return true;
    }
     public boolean hay(long cod, String file) {
        archivo = new File("assets/"+file+".txt");

        try (Scanner lector = new Scanner(archivo)) {

            while (lector.hasNextLine()) {

                String linea = lector.nextLine();
                String[] datos = linea.split(",");

                long codigo = Long.parseLong(datos[0]);
                String nombre = datos[1];
                Float precio = Float.parseFloat(datos[2]);
                
                if(codigo == cod){
                    lector.close();
                    return verSiHay(datos);
                }


            }
        } catch (FileNotFoundException ex) {
            mostrarError("Archivo no existe", "No se pudo encontrar el archivo");
        } catch (NullPointerException ex) {
            mostrarError("Formato equivocado", "El archivo no tiene el formato correcto");
        } catch (NumberFormatException ex) {
            mostrarError("Formato equivocado", "Los tipos de datos no coinciden");
        } 
        
        return true;
     }

    void mostrarError(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(null,
                mensaje,
                titulo,
                JOptionPane.ERROR_MESSAGE);
    }

    public void cargar_archivos_Postre(JTable tabla) {
        archivo = new File("assets/Postres.txt");
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();

        try (Scanner lector = new Scanner(archivo)) {

            while (lector.hasNextLine()) {

                String linea = lector.nextLine();
                String[] datos = linea.split(",");

                long codigo = Long.parseLong(datos[0]);
                String nombre = datos[1];
                Float precio = Float.parseFloat(datos[2]);

                model.addRow(new Object[]{codigo, nombre, precio});

            }
        } catch (FileNotFoundException ex) {
            mostrarError("Archivo no existe", "No se pudo encontrar el archivo");
        } catch (NullPointerException ex) {
            mostrarError("Formato equivocado", "El archivo no tiene el formato correcto");
            Limpiar_tabla.limpiar(tabla);
        } catch (NumberFormatException ex) {
            mostrarError("Formato equivocado", "Los tipos de datos no coinciden");
            Limpiar_tabla.limpiar(tabla);
        } catch (Exception ex) {
            mostrarError("Error", "Algo inesperado ocurrió");
            Limpiar_tabla.limpiar(tabla);
            ex.printStackTrace();
        }

    }

    public void cargar_Postres(JTable tabla) {
        archivo = new File("assets/Postres.txt");
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();

        try (Scanner lector = new Scanner(archivo)) {

            while (lector.hasNextLine()) {

                String linea = lector.nextLine();
                String[] datos = linea.split(",");

                long codigo = Long.parseLong(datos[0]);
                String nombre = datos[1];

                model.addRow(new Object[]{codigo, nombre});

            }
        } catch (FileNotFoundException ex) {
            mostrarError("Archivo no existe", "No se pudo encontrar el archivo");
        } catch (NullPointerException ex) {
            mostrarError("Formato equivocado", "El archivo no tiene el formato correcto");
            Limpiar_tabla.limpiar(tabla);
        } catch (NumberFormatException ex) {
            mostrarError("Formato equivocado", "Los tipos de datos no coinciden");
            Limpiar_tabla.limpiar(tabla);
        } catch (Exception ex) {
            mostrarError("Error", "Algo inesperado ocurrió");
            Limpiar_tabla.limpiar(tabla);
            ex.printStackTrace();
        }

    }

    public void cargar_ingredientes(JTable tabla, long cod) {
        archivo = new File("assets/Postres.txt");
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();

        try (Scanner lector = new Scanner(archivo)) {

            while (lector.hasNextLine()) {

                String linea = lector.nextLine();
                String[] datos = linea.split(",");

                long codigo = Long.parseLong(datos[0]);
                if (codigo == cod) {
                    for (int i = 3; i < datos.length; i++) {
                        model.addRow(new Object[]{datos[i]});
                    }
                    break;
                }

            }
        } catch (FileNotFoundException ex) {
            mostrarError("Archivo no existe", "No se pudo encontrar el archivo");
        } catch (NullPointerException ex) {
            mostrarError("Formato equivocado", "El archivo no tiene el formato correcto");
            Limpiar_tabla.limpiar(tabla);
        } catch (NumberFormatException ex) {
            mostrarError("Formato equivocado", "Los tipos de datos no coinciden");
            Limpiar_tabla.limpiar(tabla);
        } catch (Exception ex) {
            mostrarError("Error", "Algo inesperado ocurrió");
            Limpiar_tabla.limpiar(tabla);
            ex.printStackTrace();
        }

    }

}
