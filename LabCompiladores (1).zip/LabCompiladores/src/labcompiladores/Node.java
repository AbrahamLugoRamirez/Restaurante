/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labcompiladores;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author carlo
 */
public class Node {
    private Node rightNode;
    private Node leftNode;
    private Node parentNode;
    private int ID;
    private boolean tag;
    private char name;
    private int pos;
    private static int i=1;
    private ArrayList<Integer> firstPos;
    private ArrayList<Integer> lastPos;
    private ArrayList<Integer> nextPos;
    public int x,y;
    
    public Node(char name) {
        this.name = name;
        nextPos=new ArrayList();
        if (this.name!='*' && this.name!='+' && this.name!='.' && this.name!='|' && this.name!='?' && this.name!='&') {
            this.tag = true;
            this.pos=i;
            i++;
        }else this.tag=false;
    }

    public ArrayList<Integer> getNextPos() {
        return nextPos;
    }

    public void setNextPos(ArrayList<Integer> nextPos) {
        this.nextPos = nextPos;
    }

    public static void setI(int i) {
        Node.i = i;
    }
    
    public void setPosition(int x,int y){
        this.x=x;
        this.y=y;
    }

    public ArrayList<Integer> getFirstPos() {
        return firstPos;
    }

    public void setFirstPos(String firstPos) {
        String fp[]=firstPos.split("");
        ArrayList<Integer> s=new ArrayList();
        for (int j = 0; j < fp.length; j++) {
            if (!s.contains(Integer.parseInt(fp[j]))) {
                s.add(Integer.parseInt(fp[j]));
            }
        }
        this.firstPos = s;
    }

    public ArrayList<Integer> getLastPos() {
        return lastPos;
    }

    public void setLastPos(String lastPos) {
        String fp[]=lastPos.split("");
        ArrayList<Integer> s=new ArrayList();
        for (int j = 0; j < fp.length; j++) {
            if (!s.contains(Integer.parseInt(fp[j]))) {
                s.add(Integer.parseInt(fp[j]));
            }
        }
        this.lastPos = s;
    }

    public boolean getTag() {
        return tag;
    }

    public void setTag(boolean tag) {
        this.tag = tag;
    }
    
    public Boolean anulable(){
        if (name=='&') {
            return true;
        }else if (this.tag==true || this.name=='+') {
            return false;
        }else{
            if (this.name=='?' || this.name=='*') {
                return true;
            }else if(this.name=='|'){
                return (leftNode.anulable() || rightNode.anulable());
            }else if (this.name=='.') {
                return (leftNode.anulable() && rightNode.anulable());
            }
        }
        return null;
    }
    
    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public char getName() {
        return name;
    }

    public void setName(char name) {
        this.name = name;
    }  
    
    public Node getRightNode() {
        return rightNode;
    }

    public void setRightNode(Node rightNode) {
        this.rightNode = rightNode;
    }

    public Node getLeftNode() {
        return leftNode;
    }

    public void setLeftNode(Node leftNode) {
        this.leftNode = leftNode;
    }

    public Node getParentNode() {
        return parentNode;
    }

    public void setParentNode(Node parentNode) {
        this.parentNode = parentNode;
    }

}
