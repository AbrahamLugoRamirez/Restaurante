/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labcompiladores;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

public class Painter extends Canvas{
    
    public void drawArbol(Graphics g,ArrayList<Node> nodos, double m){
        int i=0;
        g.clearRect(0, 0, 1000, 1000);
        nodos.get(0).setPosition((int)(m/2+200),30);
        for(Node dato:nodos){
            g.setColor(Color.white);
            g.fillOval(dato.x-10, dato.y-10, 20, 20);
            if(dato.getName()=='.' || dato.getName()=='|'){
                dato.getLeftNode().setPosition(dato.x-80+i*8,dato.y+50);
                g.drawLine(dato.x, dato.y,dato.getLeftNode().x, dato.getLeftNode().y);
                dato.getRightNode().setPosition(dato.x+80-i*8,dato.y+50);
                g.drawLine(dato.x, dato.y,dato.getRightNode().x, dato.getRightNode().y);
            }else{
                if(dato.getLeftNode()!=null){
                    dato.getLeftNode().setPosition(dato.x,dato.y+50);
                    g.drawLine(dato.x, dato.y,dato.getLeftNode().x, dato.getLeftNode().y);
                }
            }
            g.setColor(Color.black);
            g.drawString(dato.getName()+"", dato.x-3,dato.y+5);
            if (dato.getName()!='&') {
                g.drawString("PP:"+ dato.getFirstPos()+"", dato.x-20,dato.y-12);
                g.drawString("UP:"+dato.getLastPos()+"", dato.x-20,dato.y+20);
            }
            i++;
        }
    }
}

