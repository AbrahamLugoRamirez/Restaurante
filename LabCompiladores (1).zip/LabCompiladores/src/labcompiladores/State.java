/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labcompiladores;

import java.util.ArrayList;

/**
 *
 * @author carlo
 */
public class State {
    private ArrayList<Integer> Set;
    private boolean Tag;
    private boolean End;
    private char name;
    private char[] names={'A','B','C','D','E','F','G','H','I','J','K'};
    private static int i=0;
    
    public State(ArrayList<Integer> Estado) {
        this.Set = Estado;
        this.Tag = false;
        this.name= names[i];
        i++;
        this.End=false;
    }

    public void endState(int pos){
        if (this.Set.contains(pos)) {
            this.End=true;
        }
    }
    
    public static void setI(int i) {
        State.i = i;
    }

    public boolean isEnd() {
        return End;
    }

    public void setEnd(boolean End) {
        this.End = End;
    }

    public char getName() {
        return name;
    }

    public ArrayList<Integer> getSet() {
        return Set;
    }

    public void setSet(ArrayList<Integer> Set) {
        this.Set = Set;
    }

    public void setName(char name) {
        this.name = name;
    }

    public boolean isTag() {
        return Tag;
    }

    public void setTag(boolean Tag) {
        this.Tag = Tag;
    }
    
    
}
