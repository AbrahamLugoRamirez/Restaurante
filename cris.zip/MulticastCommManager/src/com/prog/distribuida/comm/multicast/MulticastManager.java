/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prog.distribuida.comm.multicast;

import java.awt.List;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author asaad
 */
public class MulticastManager extends Thread {

    String file;
    MulticastSocket multicastSocket;
    private String ipAddress;
    private int port;
    private MulticastManagerCallerInterface caller;
    private boolean isEnable = true;
    byte[] by;
    ArrayList<File> f = new ArrayList<File>();
    ArrayList<byte[]> byt = new ArrayList<byte[]>();

    String name = "hola.txt";
    int tamaño;
    String file_name;
    String num_packets2;
    double file_length;
    int num_packets;
    int offset;

    BufferedInputStream bis;
    BufferedOutputStream bos;

    public MulticastManager(String ipAddress, int port, MulticastManagerCallerInterface caller) {
        this.ipAddress = ipAddress;
        this.port = port;
        this.caller = caller;
        this.start();
    }

    public boolean InitializeMulticastSocket() {
        try {
            this.multicastSocket = new MulticastSocket(69);
            InetAddress inetAddress = InetAddress.getByName(ipAddress);
            multicastSocket.joinGroup(inetAddress);
            return true;
        } catch (Exception ex) {
            caller.ErrorHasBeenThrown(ex);
            return false;
        }
    }

    @Override
    public void run() {
        int cont = 0;
        int cont2 = 0;
        String tt = "";
        if (InitializeMulticastSocket()) {
            int o = 1;
            while (isEnable) {
                try {
                    DatagramPacket datagramPacket = new DatagramPacket(new byte[1500], 1500);
                    //System.out.println("Entre");
                    multicastSocket.receive(datagramPacket);
//                    if (cont == 0) {
//                        bos = new BufferedOutputStream(new FileOutputStream(name));
//                        cont++;
//                    }
                    if (cont2 == 0) {
                        String d;
                        file_name = new String(datagramPacket.getData());
                        for (int i = 0; i < file_name.length(); i++) {
                            char c = file_name.charAt(i);
                            try {
                                if (Character.isLetter(c) || (".".charAt(0) == c)) {
                                    tt = tt + c;
                                }
                            } catch (Exception e) {
                                System.out.println("dddddddddd");
                            }
                        }
                        file_name = tt;
                        bos = new BufferedOutputStream(new FileOutputStream(file_name));
                        cont2++;
                    } else {
                        if (cont2 == 1) {
                            tt = "";
                            num_packets2 = (new String(datagramPacket.getData()));
                            for (int i = 0; i < num_packets2.length(); i++) {
                                char c = num_packets2.charAt(i);
                                try {
                                    int d = c;
                                    if (d != 0) {
                                        tt = tt + c;
                                    }
                                } catch (Exception e) {
                                    System.out.println("dddddddddd");
                                }
                            }
                            file_length = Double.parseDouble(tt);
                            num_packets = (int)((file_length / 1500) + 1);
                            System.out.println("El numero de paquetes a recibir son: " + num_packets);
                            offset = (int)(file_length % 1500);
                            System.out.println("Yo soy el offser: "+offset);
                            cont2++;
                        } else {
                            if (cont == num_packets - 1) {
                                //caller.MessageReceived(ipAddress, port, datagramPacket.getData());
                                bos.write(datagramPacket.getData(), 0, (int)offset);
                                bos.flush();
                                bos.close();
                                cont++;
                                System.out.println("  R  " + cont);
                                System.out.println("Paso por el ultimo paquete");
                            } else {
                                if(cont < num_packets-1)
                                //caller.MessageReceived(ipAddress, port, datagramPacket.getData());
                                bos.write(datagramPacket.getData());
                                bos.flush();
                                cont++;
                                System.out.println("  R  " + cont);
                            }  
                        }
                    }

                    //caller.MessageReceived(datagramPacket.getAddress().toString(),
                    //datagramPacket.getPort(), datagramPacket.getData());
                    //String str = new String(datagramPacket.getData(), 0, datagramPacket.getLength());
                    //System.out.println("str::" + str);
//                    tamaño = tamaño+ datagramPacket.getLength();
//                    System.out.println("Tamaño: " +tamaño +"  Bytes");
//                    if (str.equals("Terminado")){
//                        System.out.println("Se termino de enviar los archivos");
//                        File h = new File(name);
//                        System.out.println("-----" + byt.size());
//                        
//                        
////                        byte[] filename= byt.get(byt.size()-1);                        
////                        String filee = new String(filename);
////                        System.out.println("FIlee nemw" +filee);
//                        bos = new BufferedOutputStream(new FileOutputStream(name));
//                        
//                        for (byte[] b : byt) {
//                            bos.write(b, 0, b.length);
//                            bos.flush();
//                        }
//                        
//                    
//                        
//                        
//                        
////                        UnirArchivo(f, h);
//                        bos.close();
////                        bis.close();
//
//                        name = null;
//                        f = null;
//
//                    } else {
//                        name = "hellooo.txt";
//                        file = "hello.txt";
////                        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file + o));
////                        bos.write(datagramPacket.getData(), 0, datagramPacket.getLength());
//////                        File localFile = new File(file + o);
////                        
////                        bos.close();
//
////                        System.out.println("Se cerro");
////                        byte[] receivedData = new byte[1500];
////
////                        DataInputStream dis = new DataInputStream(new ByteArrayInputStream(datagramPacket.getData(), datagramPacket.getOffset(), datagramPacket.getLength()));
////                        bis = new BufferedInputStream(new ByteArrayInputStream(datagramPacket.getData(), datagramPacket.getOffset(), datagramPacket.getLength()));
//////                        DataInputStream dis = new DataInputStream(connection.getInputStream());
////                        //Recibimos el nombre del fichero
////                        file = dis.readUTF();
////                        file = file.substring(file.indexOf('\\') + 1, file.length());
////                        
////                        System.out.println("File: " +file);
////                        bos = new BufferedOutputStream(new FileOutputStream(file + o));
////                        int in = 0;
//                        
//                        byt.add(datagramPacket.getData());
//                        
////                        while ((in = bis.read(receivedData)) > 0) {
//////                            partCounter++;
////                            bos.write(receivedData, 0, in);
////                            System.out.println("Recibiendo...");
//////                              System.out.println("Data: "+datagramPacket.getData());
//////                              System.out.println("In: "+in);
//////                           multicastManager.SendThisMessage(file.getBytes());  
////
////                        }
////                        bos.close();
////                        bis.close();
////
////                        f.add(new File(file + o));
////                        o++;
//
//                    }
                } catch (IOException ex) {
                    caller.ErrorHasBeenThrown(ex);
                    Logger.getLogger(MulticastManager.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("Error");
                }

            }

        }

    }

    public static void UnirArchivo(ArrayList<File> files, File into)
            throws IOException {
        try (FileOutputStream fos = new FileOutputStream(into);
                BufferedOutputStream mergingStream = new BufferedOutputStream(fos)) {

            for (File f : files) {
//             
                Files.copy(f.toPath(), mergingStream);

            }
            System.out.println("This is ");

        }
    }

    public boolean SendThisMessage(String destAddress, int dstPort, byte[] payload) {
        try {
            DatagramPacket outgoingPacket = new DatagramPacket(payload, payload.length);
            outgoingPacket.setAddress(InetAddress.getByName(destAddress));
            outgoingPacket.setPort(dstPort);
            outgoingPacket.setData(payload);
            multicastSocket.send(outgoingPacket);
            return true;
        } catch (Exception ex) {
            caller.ErrorHasBeenThrown(ex);
            return false;
        }
    }

    public boolean SendThisMessage(byte[] payload) {
        try {
            DatagramPacket outgoingPacket = new DatagramPacket(payload, payload.length);
            outgoingPacket.setAddress(InetAddress.getByName(ipAddress));
            outgoingPacket.setPort(port);
            outgoingPacket.setData(payload);
            multicastSocket.send(outgoingPacket);

            return true;
        } catch (Exception ex) {
            caller.ErrorHasBeenThrown(ex);
            return false;
        }
    }

}
