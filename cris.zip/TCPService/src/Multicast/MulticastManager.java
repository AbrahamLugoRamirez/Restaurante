/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Multicast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author asaad
 */
public class MulticastManager extends Thread {

    String file;
    MulticastSocket multicastSocket;
    private String ipAddress;
    private int port;
    private MulticastManagerCallerInterface caller;
    private boolean isEnable = true;
    byte[] by;
    ArrayList<File> f = new ArrayList<File>();

    String name;
    int tamaño;

    BufferedInputStream bis;
    BufferedOutputStream bos;

    public MulticastManager(String ipAddress, int port, MulticastManagerCallerInterface caller) {
        this.ipAddress = ipAddress;
        this.port = port;
        this.caller = caller;
        InitializeMulticastSocket();
        this.start();
    }

    public boolean InitializeMulticastSocket() {
        try {
            this.multicastSocket = new MulticastSocket(69);
            InetAddress inetAddress = InetAddress.getByName(ipAddress);
            multicastSocket.joinGroup(inetAddress);
            return true;
            } catch (Exception ex) {
            caller.ErrorHasBeenThrown(ex);
            return false;
        }
    }

    @Override
    public void run() {
        
        //DatagramPacket datagramPacket = new DatagramPacket(new byte[1500], 1500);
        //if (InitializeMulticastSocket()) {
            //System.out.println("lo cogio");
//            int o = 1;
//            while (isEnable) {
//                try {
//
//                    multicastSocket.receive(datagramPacket);
//                    //caller.MessageReceived(datagramPacket.getAddress().toString(),
//                            //datagramPacket.getPort(), datagramPacket.getData());
//
//                    String str = new String(datagramPacket.getData(), 0, datagramPacket.getLength());
//                    System.out.println("str::" + str);
////                 
//                } catch (IOException ex) {
//                    Logger.getLogger(MulticastManager.class.getName()).log(Level.SEVERE, null, ex);
//                }
//                System.out.println("Queeee");
//            }
//            System.out.println("DImelo");
        //}
    }

    public static void UnirArchivo(ArrayList<File> files, File into)
            throws IOException {
        try (FileOutputStream fos = new FileOutputStream(into);
                BufferedOutputStream mergingStream = new BufferedOutputStream(fos)) {

            for (File f : files) {
//             
                Files.copy(f.toPath(), mergingStream);

            }
            System.out.println("This is ");

        }
    }

    public boolean SendThisMessage(String destAddress, int dstPort, byte[] payload) {
        try {
            DatagramPacket outgoingPacket = new DatagramPacket(payload, payload.length);
            outgoingPacket.setAddress(InetAddress.getByName(destAddress));
            outgoingPacket.setPort(dstPort);
            outgoingPacket.setData(payload);
            multicastSocket.send(outgoingPacket);
            return true;
        } catch (Exception ex) {
            caller.ErrorHasBeenThrown(ex);
            return false;
        }
    }

    public boolean SendThisMessage(byte[] payload) {
        try {
            DatagramPacket outgoingPacket = new DatagramPacket(payload, payload.length);
            outgoingPacket.setAddress(InetAddress.getByName(ipAddress));
            outgoingPacket.setPort(port);
//            outgoingPacket.setData(payload);
            outgoingPacket.setData(payload);
            multicastSocket.send(outgoingPacket);

            return true;
        } catch (Exception ex) {
            caller.ErrorHasBeenThrown(ex);
            return false;
        }
    }

    public void SendThisMessage(int in) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
