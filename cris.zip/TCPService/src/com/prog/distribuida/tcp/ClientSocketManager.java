package com.prog.distribuida.tcp;


import com.prog.distribuida.tcp.TCPServiceManagerCallerInterface;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JOptionPane;

public class ClientSocketManager extends Thread {

    Socket clientSocket;
    BufferedReader reader;
    PrintWriter writer;
    boolean isEnabled = true;
    private TCPServiceManagerCallerInterface caller;
    private String serverIpAddress;
    private int port;
    

//    -----------------------------
    DataInputStream input;
    BufferedInputStream bis;
    BufferedOutputStream bos;
    int in;
    byte[] byteArray;
//    ---------------------------

    public ClientSocketManager(Socket clientSocket,
            TCPServiceManagerCallerInterface caller) {
        this.clientSocket = clientSocket;
        this.start();
        this.caller = caller;
    }

    public ClientSocketManager(String serverIpAddress,
            int port,
            TCPServiceManagerCallerInterface caller) {
        this.serverIpAddress = serverIpAddress;
        this.port = port;
        this.caller = caller;
        this.start();
    }

    public boolean initializeSocket() {
        try {
            this.clientSocket = new Socket(serverIpAddress, port);
            return true;
        } catch (Exception ex) {

        }
        return false;
    }

    public boolean initializeStreams() {
        try {
            if (clientSocket == null) {
                if (!initializeSocket()) {
                    return false;
                }
            }
            reader = new BufferedReader(
                    new InputStreamReader(clientSocket.getInputStream()));
            writer = new PrintWriter(
                    new OutputStreamWriter(clientSocket.getOutputStream()), true);
            return true;
        } catch (Exception ex) {
            caller.ErrorHasBeenThrown(ex);
        }
        return false;
    }

    @Override
    public void run() {
        try {
            if (initializeStreams()) {
                String newMessage = null;
                while ((newMessage = this.reader.readLine()) != null) {

                    caller.MessageReceiveFromClient(clientSocket, newMessage.getBytes());
                }
            }
        } catch (Exception ex) {

        }
    }

    public void SendMessage(String message) {
        try {
            if (clientSocket.isConnected()) {
                writer.write(message + "\n");
                writer.flush();
            }
        } catch (Exception ex) {
            caller.ErrorHasBeenThrown(ex);
        }
    }

    public void SendMessage1(String ruta) {
        String file_name;
        double file_length;
        try {
            final File localFile = new File(ruta);
            Socket client = new Socket(serverIpAddress, port);
            file_name = localFile.getName(); 
            bis = new BufferedInputStream(new FileInputStream(localFile));
            bos = new BufferedOutputStream(client.getOutputStream());
            //Enviamos el nombre del fichero
            DataOutputStream dos = new DataOutputStream(client.getOutputStream());
            file_length = (double) Math.abs(localFile.length());
            dos.writeUTF(file_name+"-"+file_length);

            //Enviamos el fichero
            byteArray = new byte[1500];

            while ((in = bis.read(byteArray)) != -1) {

                bos.write(byteArray, 0, in);
                bos.flush();
                System.out.println("Enviando...");

            }
            //Cerramos el Bis y bos
            bis.close();
            bos.close();
            //JOptionPane.showMessageDialog(null, "Archivo enviado correctamente");

        } catch (Exception e) {
            System.err.println(e);
        }

    }

}
