/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prog.distribuida.tcp;


import Multicast.MulticastManager;
import Multicast.MulticastManagerCallerInterface;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Administrador
 */
public class TCPServiceManager extends Thread implements TCPServiceManagerCallerInterface, MulticastManagerCallerInterface {

    MulticastManager multicastManager = null;
    ServerSocket serverSocket;
    private int port;
    private TCPServiceManagerCallerInterface caller;
    boolean isEnabled = true;
    Vector<ClientSocketManager> clients = new Vector<ClientSocketManager>();
    ObjectInputStream wri;
    ObjectOutputStream rea;
    MulticastSocket multicastSocket;
//    ---------------------
    ServerSocket server;
    Socket connection;

    DataOutputStream output;
    BufferedInputStream bis;
    BufferedOutputStream bos;

    byte[] receivedData;
    int in = 0;
    String file;

//  ------------
    public TCPServiceManager(int port,
            TCPServiceManagerCallerInterface caller) {
        this.port = port;
        this.caller = caller;
        this.start();
    }

    public void SendMessageToAllClients(String message) {
        for (ClientSocketManager current : clients) {
            if (current != null) {
                current.SendMessage(message);
            }
        }
    }

    @Override
    public void run() {
        int cont = 0;
        try {
            this.serverSocket = new ServerSocket(port);

            while (this.isEnabled) {
                clients.add(new ClientSocketManager(serverSocket.accept(), this));

                try {
                    int partCounter = 0;//
                    //System.out.println("entro maso");
                    while (true) {
                        //Aceptar conexiones
                        connection = serverSocket.accept();
                        //Buffer de 1024 bytes
                        receivedData = new byte[1500];
                        bis = new BufferedInputStream(connection.getInputStream());
                        DataInputStream dis = new DataInputStream(connection.getInputStream());
                        //Recibimos el nombre del fichero
                        file = dis.readUTF();
                        String [] length = file.split("-");
                        //System.out.println(length[1]);
                        //file = file.substring(file.indexOf('\\') + 1, Arrays.toString(length[0].getBytes()).length());
                        bos = new BufferedOutputStream(new FileOutputStream(length[0]));
                        //Para guardar fichero recibido  

                        try {
                            if (multicastManager == null) {
                                this.multicastManager = new MulticastManager("224.0.0.2", 69, this);
                                multicastManager.SendThisMessage(length[0].getBytes());
                                multicastManager.SendThisMessage(length[1].getBytes());
                                //System.out.println("This is connect");
                            }
                            while ((in = bis.read(receivedData)) > 0) {
                                multicastManager.SendThisMessage(receivedData);
                                bos.write(receivedData, 0, in);
                                bos.flush();
                                cont++;
                                System.out.println("E "+cont);
                                //serverSocket.wait();
                            }
                            bos.close();
                            dis.close();
                        } catch (Exception error) {
                            System.out.println("Error");
                        }

//                        try {
//                            if (multicastManager == null) {
//                               this.multicastManager = new MulticastManager("224.0.0.2", port, this);
//                            }
//                        } catch (Exception error) {
//                            System.out.println("Error");
//                        }
//                        if ((in = bis.read(receivedData)) == -1) {
//
//                            System.out.println("Se envio el terminado");
//                            multicastManager.SendThisMessage("Terminado".getBytes());
//
//                        }
////                        Chunks(dis, bos);
//                        bos.close();
//                        dis.close();
                    }
                } catch (Exception e) {
                    System.err.println(e);
                }

            }
        } catch (Exception error) {
            this.caller.ErrorHasBeenThrown(error);
        }
    }

    @Override
    public void MessageReceiveFromClient(Socket clientSocket, byte[] data) {
        SendMessageToAllClients(
                clientSocket.getInetAddress().
                        getHostName() + ":" + clientSocket.getPort()
                + ": " + new String(data));

    }

    @Override
    public void MessageReceived(String sourceIpAddressOrHost, int sourcePort, byte[] data) {
//        jTextArea1.append(sourceIpAddressOrHost + ":" + sourcePort + " - "
//                + new String(data) + "\n");
    }

    @Override
    public void ErrorHasBeenThrown(Exception error) {
//        jTextArea1.append(error.getMessage() + "\n");
    }

}
